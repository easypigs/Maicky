import React from "react";
import Home from "./components/home/home";
import Contact from "./components/courses/courses";
import Formulario from './components/courses/formulario'
import Editar from './components/courses/editar'
import { Container } from 'react-materialize';
import { Routes, Route } from 'react-router-dom'

const Main = (props) => (
  <main>
    <Container>
      <Routes>
        <Route exact path='/' element={ <Home/> }/>
        <Route path='/courses' element={ <Contact coursesData={props.coursesData}/> }/>
        <Route path='/formulario' element={ <Formulario /> }/>
        <Route path='/formulario/editar/:colecaoId' element={ <Editar /> }/>
      </Routes>
    </Container>
  </main>  
);

export default Main;